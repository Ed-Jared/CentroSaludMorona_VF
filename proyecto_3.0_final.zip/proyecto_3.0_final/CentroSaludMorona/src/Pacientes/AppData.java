package Pacientes;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class AppData {
  public static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private static final Path DATA_DIR = Paths.get("data");
  private static final Path NURSES_FILE = DATA_DIR.resolve("enfermeros.txt");
  private static final Path PATIENTS_FILE = DATA_DIR.resolve("pacientes.txt");
  private static final Path DOCTORS_FILE = DATA_DIR.resolve("medicos.txt");
  private static final Path DOCTOR_ACCESS_FILE = DATA_DIR.resolve("acceso_medicos.txt");
  private static final String SEP = "|";
  private static final Map<String, List<String>> DOCTORS = new LinkedHashMap<>();

  static {
    DOCTORS.put("Medicina General", Arrays.asList("Andy Aguirre", "Melody Garcia"));
    DOCTORS.put("Pediatría", Arrays.asList("Kevin Pacora", "Andre Machuca"));
    DOCTORS.put("Odontología", Arrays.asList("Jonatan Niño", "Jose Quispe"));
    DOCTORS.put("Psicología", Arrays.asList("Edwin Villanueva", "Lilit Saguirre"));
    DOCTORS.put("Obstetricia", Arrays.asList("David Siancas", "Maricielo Sánchez"));
  }

  private AppData() {}

  public static void ensureFiles() {
    try {
      Files.createDirectories(DATA_DIR);
      if (!Files.exists(NURSES_FILE)) Files.createFile(NURSES_FILE);
      if (!Files.exists(PATIENTS_FILE)) Files.createFile(PATIENTS_FILE);
      if (!Files.exists(DOCTOR_ACCESS_FILE)) Files.createFile(DOCTOR_ACCESS_FILE);
      List<String> doctorLines = new ArrayList<>();
      for (Map.Entry<String, List<String>> e : DOCTORS.entrySet())
        for (String doctor : e.getValue()) doctorLines.add(e.getKey() + SEP + doctor);
      if (!Files.exists(DOCTORS_FILE))
        Files.write(DOCTORS_FILE, doctorLines, StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new RuntimeException("No se pudo preparar la base de datos", e);
    }
  }

  private static List<String> read(Path file) {
    ensureFiles();
    try {
      return Files.readAllLines(file, StandardCharsets.UTF_8);
    } catch (IOException e) {
      return new ArrayList<>();
    }
  }

  private static void write(Path file, List<String> lines) {
    ensureFiles();
    try {
      Files.write(file, lines, StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new RuntimeException("No se pudo guardar la información", e);
    }
  }

  public static synchronized boolean addNurse(String user, String password) {
    if (user.isBlank() || password.isBlank() || findNurse(user) != null) return false;
    List<String> lines = read(NURSES_FILE);
    lines.add(user + SEP + password);
    write(NURSES_FILE, lines);
    return true;
  }

  public static String findNurse(String user) {
    for (String line : read(NURSES_FILE)) {
      String[] p = line.split("\\|", -1);
      if (p.length >= 2 && p[0].equals(user)) return p[1];
    }
    return null;
  }

  /**
   * Returns patients using the current 8-field format:
   * names|surnames|dni|specialty|doctor|date|time|age
   *
   * Older records (6 or 7 fields) remain readable; their age is treated as
   * unknown and represented by 0 until the patient is edited/updated.
   */
  public static List<String[]> patients() {
    List<String[]> result = new ArrayList<>();
    for (String line : read(PATIENTS_FILE)) {
      String[] p = line.split("\\|", -1);
      if (p.length == 8) {
        result.add(p);
      } else if (p.length == 7) {
        String[] withAge = Arrays.copyOf(p, 8);
        withAge[7] = "0";
        result.add(withAge);
      } else if (p.length == 6) {
        String[] normalized = Arrays.copyOf(p, 8);
        normalized[6] = "00:00";
        normalized[7] = "0";
        result.add(normalized);
      }
    }
    return result;
  }

  public static synchronized void addPatient(String[] patient) {
    List<String> lines = read(PATIENTS_FILE);
    lines.add(String.join(SEP, patient));
    write(PATIENTS_FILE, lines);
  }

  public static synchronized boolean updatePatient(String dni, String[] updated) {
    List<String> lines = read(PATIENTS_FILE);
    boolean changed = false;
    for (int i = 0; i < lines.size(); i++) {
      String[] p = lines.get(i).split("\\|", -1);
      if ((p.length >= 6 && p.length <= 8) && p[2].equals(dni)) {
        lines.set(i, String.join(SEP, updated));
        changed = true;
        break;
      }
    }
    if (changed) write(PATIENTS_FILE, lines);
    return changed;
  }

  public static synchronized boolean deletePatient(String dni) {
    List<String> lines = read(PATIENTS_FILE);
    boolean changed =
        lines.removeIf(
            line -> {
              String[] p = line.split("\\|", -1);
              return (p.length >= 6 && p.length <= 8) && p[2].equals(dni);
            });
    if (changed) write(PATIENTS_FILE, lines);
    return changed;
  }

  public static synchronized void clearPatients() {
    write(PATIENTS_FILE, new ArrayList<>());
  }

  /**
   * Medicos por especialidad: los iniciales mas los registrados en medicos.txt. Se lee del
   * archivo en cada llamada, asi un medico nuevo aparece al instante sin reiniciar.
   */
  private static Map<String, List<String>> loadDoctorMap() {
    Map<String, List<String>> map = new LinkedHashMap<>();
    for (Map.Entry<String, List<String>> e : DOCTORS.entrySet())
      map.put(e.getKey(), new ArrayList<>(e.getValue()));
    for (String line : read(DOCTORS_FILE)) {
      String[] p = line.split("\\|", -1);
      if (p.length < 2 || p[0].isBlank() || p[1].isBlank()) continue;
      List<String> names = map.computeIfAbsent(p[0].trim(), k -> new ArrayList<>());
      if (!names.contains(p[1].trim())) names.add(p[1].trim());
    }
    return map;
  }

  public static List<String> specialties() {
    return new ArrayList<>(loadDoctorMap().keySet());
  }

  public static List<String> doctorsFor(String specialty) {
    return loadDoctorMap().getOrDefault(specialty, Collections.emptyList());
  }

  public static boolean validDni(String dni) {
    return dni != null && dni.matches("[1-9]\\d{7}");
  }

  public static boolean validName(String value) {
    return value != null && value.trim().matches("[\\p{L}]+(?:[ \\p{L}]+)*");
  }

  public static boolean validAge(String value) {
    return value != null && value.trim().matches("(?:[1-9]|[1-9][0-9]|1[01][0-9]|120)");
  }

  public static boolean validFutureDate(String date) {
    try {
      return LocalDate.parse(date, DATE_FORMAT).isAfter(LocalDate.now());
    } catch (DateTimeParseException e) {
      return false;
    }
  }

  public static String[] findPatient(String dni) {
    for (String[] p : patients()) if (p[2].equals(dni)) return p;
    return null;
  }

  public static synchronized boolean addDoctor(String user, String specialty, String password) {
    if (user == null || user.isBlank() || specialty == null || specialty.isBlank()
        || password == null || password.isBlank() || doctorPassword(user) != null) return false;
    List<String> lines = read(DOCTOR_ACCESS_FILE);
    lines.add(user + SEP + specialty + SEP + password);
    write(DOCTOR_ACCESS_FILE, lines);
    // Tambien se agrega a medicos.txt para que aparezca de inmediato al registrar pacientes.
    List<String> doctorLines = read(DOCTORS_FILE);
    doctorLines.add(specialty + SEP + user);
    write(DOCTORS_FILE, doctorLines);
    return true;
  }

  public static String doctorPassword(String user) {
    for (String line : read(DOCTOR_ACCESS_FILE)) {
      String[] p = line.split("\\|", -1);
      if (p.length >= 3 && p[0].equalsIgnoreCase(user)) return p[2];
    }
    return null;
  }

  public static List<String[]> doctors() {
    List<String[]> result = new ArrayList<>();
    for (String line : read(DOCTOR_ACCESS_FILE)) {
      String[] p = line.split("\\|", -1);
      if (p.length >= 3) result.add(new String[] {p[0], p[1], p[2]});
    }
    return result;
  }
}
