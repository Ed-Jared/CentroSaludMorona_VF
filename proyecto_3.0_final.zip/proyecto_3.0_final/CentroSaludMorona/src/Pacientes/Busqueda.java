package Pacientes;

import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;

public class Busqueda extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextField dni = new JTextField();

  public Busqueda(JDialog owner) {
    super(owner, "Buscar Paciente", true);
    build();
  }

  public Busqueda() {
    this(null);
  }

  private void build() {
    setBounds(100, 100, 320, 170);
    setLocationRelativeTo(getOwner());
    JPanel p = new JPanel(null);
    setContentPane(p);
    JLabel l = new JLabel("DNI (8 dígitos):");
    l.setBounds(20, 25, 110, 25);
    p.add(l);
    dni.setBounds(135, 23, 145, 28);
    ((AbstractDocument) dni.getDocument()).setDocumentFilter(new DigitsFilter(8, this));
    addDniFocusValidation(dni, this);
    dni.setInputVerifier(dniCompleteVerifier(this));
    p.add(dni);
    JButton b = new JButton("Buscar");
    b.setBounds(105, 75, 105, 30);
    b.addActionListener(e -> search());
    p.add(b);
    getRootPane().setDefaultButton(b);
  }

  private void search() {
    String value = dni.getText();
    if (!AppData.validDni(value)) {
      JOptionPane.showMessageDialog(
          this, "El DNI debe contener exactamente 8 números y no puede comenzar con 0.");
      return;
    }
    String[] patient = AppData.findPatient(value);
    if (patient == null) {
      JOptionPane.showMessageDialog(this, "No se encontró un paciente con ese DNI.");
      return;
    }
    dispose();
    new Paciente(this, patient).setVisible(true);
  }

  static class DigitsFilter extends DocumentFilter {
    private final int max;
    private final Component parent;

    DigitsFilter(int max, Component parent) {
      this.max = max;
      this.parent = parent;
    }

    public void insertString(FilterBypass fb, int o, String s, AttributeSet a)
        throws BadLocationException {
      replace(fb, o, 0, s, a);
    }

    public void replace(FilterBypass fb, int o, int l, String s, AttributeSet a)
        throws BadLocationException {
      String current = fb.getDocument().getText(0, fb.getDocument().getLength());
      String result = current.substring(0, o) + (s == null ? "" : s) + current.substring(o + l);
      if (result.length() > max) {
        JOptionPane.showMessageDialog(parent, "No se permiten más de " + max + " caracteres");
        return;
      }
      if (s != null
          && s.matches("\\d*")
          && !result.startsWith("0"))
        fb.replace(o, l, s, a);
    }
  }


  /** Prevents negative/non-numeric ages and prevents entering an age above the configured maximum. */
  static class AgeFilter extends DocumentFilter {
    private final int maxAge;
    private final Component parent;

    AgeFilter(int maxAge, Component parent) {
      this.maxAge = maxAge;
      this.parent = parent;
    }

    @Override
    public void insertString(FilterBypass fb, int offset, String text, AttributeSet attrs)
        throws BadLocationException {
      replace(fb, offset, 0, text, attrs);
    }

    @Override
    public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
        throws BadLocationException {
      String current = fb.getDocument().getText(0, fb.getDocument().getLength());
      String result = current.substring(0, offset)
          + (text == null ? "" : text)
          + current.substring(offset + length);
      if (result.isEmpty()) {
        fb.replace(offset, length, text == null ? "" : text, attrs);
        return;
      }
      if (!result.matches("\\d{1,3}")) {
        return;
      }
      try {
        int value = Integer.parseInt(result);
        if (value <= maxAge) {
          fb.replace(offset, length, text, attrs);
        } else {
          JOptionPane.showMessageDialog(parent, "La edad no puede ser mayor de " + maxAge + " años.");
        }
      } catch (NumberFormatException ignored) {
        // Ignore invalid input.
      }
    }
  }

  static void addDniFocusValidation(JTextField field, Component parent) {
    field.addFocusListener(
        new java.awt.event.FocusAdapter() {
          @Override
          public void focusLost(java.awt.event.FocusEvent e) {
            int length = field.getText().length();
            if (length > 0 && length < 8) {
              JOptionPane.showMessageDialog(
                  parent,
                  "El numero de caracteres en DNI es menor a 8. Por favor coloque los 8 para continuar");
            }
          }
        });
  }

  static InputVerifier dniCompleteVerifier(Component parent) {
    return new InputVerifier() {
      @Override
      public boolean verify(JComponent input) {
        JTextField field = (JTextField) input;
        String value = field.getText();
        if (value.length() == 8 && AppData.validDni(value)) return true;
        if (value.length() < 8) {
          JOptionPane.showMessageDialog(
              parent,
              "El numero de caracteres en DNI es menor a 8. Por favor coloque los 8 para continuar");
        } else {
          JOptionPane.showMessageDialog(
              parent, "El DNI debe tener 8 caracteres y no puede comenzar con 0.");
        }
        return false;
      }
    };
  }

  public static void main(String[] args) {
    new Busqueda().setVisible(true);
  }
}
