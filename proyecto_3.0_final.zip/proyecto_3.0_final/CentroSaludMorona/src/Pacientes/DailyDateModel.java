package Pacientes;

import java.util.Calendar;
import java.util.Date;
import javax.swing.SpinnerDateModel;

/** Modelo de fecha cuyo incremento siempre es de un día, sin importar el cursor del editor. */
public class DailyDateModel extends SpinnerDateModel {
  private static final long serialVersionUID = 1L;

  public DailyDateModel() {
    super(new Date(), null, null, Calendar.DAY_OF_MONTH);
  }

  @Override
  public Object getNextValue() {
    return addDays(1);
  }

  @Override
  public Object getPreviousValue() {
    return addDays(-1);
  }

  private Date addDays(int amount) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(getDate());
    calendar.add(Calendar.DAY_OF_MONTH, amount);
    return calendar.getTime();
  }
}
