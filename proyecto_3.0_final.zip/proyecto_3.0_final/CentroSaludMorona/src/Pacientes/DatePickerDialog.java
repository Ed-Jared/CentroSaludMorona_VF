package Pacientes;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class DatePickerDialog extends JDialog {
  private static final long serialVersionUID = 1L;
  private final Consumer<LocalDate> onSelected;
  private final LocalDate minimumDate = LocalDate.now().plusDays(1);
  private YearMonth visibleMonth;
  private final JLabel monthLabel = new JLabel();
  private final JPanel daysPanel = new JPanel(new GridLayout(0, 7, 2, 2));
  private final JButton previousButton = new JButton("<");

  public DatePickerDialog(Window owner, LocalDate initialDate, Consumer<LocalDate> onSelected) {
    super(owner, "Seleccionar fecha", ModalityType.APPLICATION_MODAL);
    this.onSelected = onSelected;
    LocalDate safeDate = initialDate == null || initialDate.isBefore(minimumDate)
        ? minimumDate : initialDate;
    visibleMonth = YearMonth.from(safeDate);
    build();
    refreshCalendar();
  }

  private void build() {
    setSize(360, 330);
    setLocationRelativeTo(getOwner());
    setLayout(new BorderLayout(8, 8));
    JPanel header = new JPanel(new BorderLayout(5, 5));
    previousButton.addActionListener(e -> {
      YearMonth currentMonth = YearMonth.now();
      if (visibleMonth.isAfter(currentMonth)) {
        visibleMonth = visibleMonth.minusMonths(1);
        refreshCalendar();
      }
    });
    JButton next = new JButton(">");
    next.addActionListener(e -> {
      visibleMonth = visibleMonth.plusMonths(1);
      refreshCalendar();
    });
    monthLabel.setHorizontalAlignment(SwingConstants.CENTER);
    monthLabel.setFont(monthLabel.getFont().deriveFont(16f));
    header.add(previousButton, BorderLayout.WEST);
    header.add(monthLabel, BorderLayout.CENTER);
    header.add(next, BorderLayout.EAST);
    add(header, BorderLayout.NORTH);

    JPanel center = new JPanel(new BorderLayout(3, 3));
    JPanel weekHeader = new JPanel(new GridLayout(1, 7));
    String[] weekDays = {"Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"};
    for (String day : weekDays) {
      JLabel label = new JLabel(day, SwingConstants.CENTER);
      label.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
      weekHeader.add(label);
    }
    center.add(weekHeader, BorderLayout.NORTH);
    center.add(daysPanel, BorderLayout.CENTER);
    add(center, BorderLayout.CENTER);

    JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JButton cancel = new JButton("Cancelar");
    cancel.addActionListener(e -> dispose());
    footer.add(cancel);
    add(footer, BorderLayout.SOUTH);
  }

  private void refreshCalendar() {
    String month = visibleMonth.getMonth().getDisplayName(TextStyle.FULL, new Locale("es", "ES"));
    monthLabel.setText(Character.toUpperCase(month.charAt(0)) + month.substring(1) + " " + visibleMonth.getYear());
    previousButton.setEnabled(visibleMonth.isAfter(YearMonth.now()));
    daysPanel.removeAll();
    LocalDate firstDay = visibleMonth.atDay(1);
    int offset = DayOfWeek.from(firstDay).getValue() - 1;
    for (int i = 0; i < offset; i++) daysPanel.add(new JLabel());
    for (int day = 1; day <= visibleMonth.lengthOfMonth(); day++) {
      LocalDate date = visibleMonth.atDay(day);
      JButton button = new JButton(String.valueOf(day));
      button.setMargin(new java.awt.Insets(1, 1, 1, 1));
      boolean enabled = !date.isBefore(minimumDate);
      button.setEnabled(enabled);
      if (enabled) button.addActionListener(e -> { onSelected.accept(date); dispose(); });
      daysPanel.add(button);
    }
    daysPanel.revalidate();
    daysPanel.repaint();
  }
}
