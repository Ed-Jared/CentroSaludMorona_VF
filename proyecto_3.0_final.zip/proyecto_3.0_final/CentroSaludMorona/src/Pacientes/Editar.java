package Pacientes;

import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import javax.swing.*;
import javax.swing.text.*;

public class Editar extends JDialog {
  private static final long serialVersionUID = 1L;
  private final String originalDni;
  private final JTextField dni = new JTextField(),
      names = new JTextField(),
      surnames = new JTextField(),
      age = new JTextField();
  private final JComboBox<String> specialty = new JComboBox<>(), doctor = new JComboBox<>();
  private LocalDate selectedDate = LocalDate.now().plusDays(1);
  private final JTextField dateField = new JTextField();
  private LocalTime selectedTime = LocalTime.of(0, 0);
  private final JTextField timeField = new JTextField();

  public Editar(JDialog owner, String[] patient) {
    super(owner, "Editar paciente", true);
    originalDni = patient[2];
    build(patient);
  }

  public Editar() {
    this(null, new String[] {"", "", "", "Medicina General", "", ""});
  }

  private void build(String[] p) {
    setBounds(100, 100, 430, 435);
    setLocationRelativeTo(getOwner());
    JPanel panel = new JPanel(null);
    setContentPane(panel);
    field(panel, "DNI (8 dígitos):", dni, 20);
    field(panel, "Nombres:", names, 60);
    field(panel, "Apellidos:", surnames, 100);
    field(panel, "Edad:", age, 140);
    ((AbstractDocument) age.getDocument()).setDocumentFilter(new Busqueda.AgeFilter(120, this));
    JLabel sl = label("Especialidad:", 180);
    panel.add(sl);
    for (String s : AppData.specialties()) specialty.addItem(s);
    specialty.setBounds(150, 178, 230, 28);
    specialty.addActionListener(e -> loadDoctors());
    panel.add(specialty);
    JLabel dl = label("Médico:", 220);
    panel.add(dl);
    doctor.setBounds(150, 218, 230, 28);
    panel.add(doctor);
    JLabel fl = label("Fecha:", 260);
    panel.add(fl);
    dateField.setBounds(150, 258, 160, 28);
    dateField.setEditable(false);
    panel.add(dateField);
    JButton chooseDate = new JButton("Calendario");
    chooseDate.setBounds(315, 258, 95, 28);
    chooseDate.addActionListener(e -> openDatePicker());
    panel.add(chooseDate);
    JLabel tl = label("Hora:", 300);
    panel.add(tl);
    timeField.setBounds(150, 298, 160, 28);
    timeField.setEditable(false);
    panel.add(timeField);
    JButton chooseTime = new JButton("Hora");
    chooseTime.setBounds(315, 298, 95, 28);
    chooseTime.addActionListener(e -> openTimePicker());
    panel.add(chooseTime);
    dni.setText(p[2]);
    names.setText(p[0]);
    surnames.setText(p[1]);
    age.setText(p.length > 7 && !p[7].isBlank() ? p[7] : "");
    specialty.setSelectedItem(p[3]);
    loadDoctors();
    doctor.setSelectedItem(p[4]);
    try {
      LocalDate loadedDate = LocalDate.parse(p[5], AppData.DATE_FORMAT);
      selectedDate = loadedDate.isAfter(LocalDate.now()) ? loadedDate : LocalDate.now().plusDays(1);
    } catch (Exception ignored) {
    }
    dateField.setText(selectedDate.format(AppData.DATE_FORMAT));
    try {
      selectedTime = p.length > 6 ? LocalTime.parse(p[6]) : LocalTime.of(0, 0);
    } catch (Exception ignored) {
      selectedTime = LocalTime.of(0, 0);
    }
    timeField.setText(selectedTime.toString());
    ((AbstractDocument) dni.getDocument()).setDocumentFilter(new Busqueda.DigitsFilter(8, this));
    Busqueda.addDniFocusValidation(dni, this);
    dni.setInputVerifier(Busqueda.dniCompleteVerifier(this));
    JButton save = new JButton("Guardar");
    save.setBounds(90, 355, 110, 32);
    save.addActionListener(e -> save());
    panel.add(save);
    JButton cancel = new JButton("Cancelar");
    cancel.setBounds(225, 355, 110, 32);
    cancel.addActionListener(e -> dispose());
    panel.add(cancel);
  }

  private JLabel label(String text, int y) {
    JLabel l = new JLabel(text);
    l.setBounds(20, y, 125, 28);
    return l;
  }

  private void field(JPanel p, String text, JTextField f, int y) {
    p.add(label(text, y));
    f.setBounds(150, y, 230, 28);
    p.add(f);
    if (f != dni)
      ((AbstractDocument) f.getDocument()).setDocumentFilter(new NuevoPaciente.NameFilter());
  }

  private void loadDoctors() {
    doctor.removeAllItems();
    for (String d : AppData.doctorsFor((String) specialty.getSelectedItem())) doctor.addItem(d);
  }

  private void openDatePicker() {
    DatePickerDialo picker = new DatePickerDialo(this, selectedDate, this::onDateSelected);
    picker.setVisible(true);
  }

  private void onDateSelected(LocalDate value) {
    selectedDate = value;
    dateField.setText(selectedDate.format(AppData.DATE_FORMAT));
  }

  private void openTimePicker() {
    TimePickerDialog picker = new TimePickerDialog(this, selectedTime, this::onTimeSelected);
    picker.setVisible(true);
  }

  private void onTimeSelected(LocalTime value) {
    selectedTime = value;
    timeField.setText(selectedTime.toString());
  }

  private String date() {
    return selectedDate.format(AppData.DATE_FORMAT);
  }

  private void save() {
    String d = dni.getText(), n = names.getText().trim(), s = surnames.getText().trim(), f = date();
    String ageText = age.getText().trim();
    if (!AppData.validDni(d)) {
      JOptionPane.showMessageDialog(this, "El DNI debe contener exactamente 8 números.");
      return;
    }
    if (!AppData.validAge(ageText)) {
      JOptionPane.showMessageDialog(this, "La edad debe ser un número entre 1 y 120 años.");
      return;
    }
    if (!AppData.validName(n) || !AppData.validName(s)) {
      JOptionPane.showMessageDialog(
          this, "Nombres y apellidos solo pueden contener letras y espacios.");
      return;
    }
    if (!AppData.validFutureDate(f)) {
      JOptionPane.showMessageDialog(this, "La fecha no puede ser anterior a hoy.");
      return;
    }
    if (!d.equals(originalDni) && AppData.findPatient(d) != null) {
      JOptionPane.showMessageDialog(this, "Ya existe otro paciente con ese DNI.");
      return;
    }
    AppData.updatePatient(
        originalDni,
        new String[] {
          n, s, d, (String) specialty.getSelectedItem(), (String) doctor.getSelectedItem(), f,
          selectedTime.toString(), ageText
        });
    JOptionPane.showMessageDialog(this, "Paciente actualizado correctamente.");
    dispose();
  }

  static class DailyDateModel extends SpinnerDateModel {
    private static final long serialVersionUID = 1L;

    DailyDateModel() {
      super(tomorrow(), tomorrow(), null, Calendar.DAY_OF_MONTH);
    }

    @Override
    public Object getNextValue() {
      return addDays(1);
    }

    @Override
    public Object getPreviousValue() {
      Date previous = addDays(-1);
      return previous.before((Date) getStart()) ? getStart() : previous;
    }

    private static Date tomorrow() {
      Calendar calendar = Calendar.getInstance();
      calendar.set(Calendar.HOUR_OF_DAY, 0);
      calendar.set(Calendar.MINUTE, 0);
      calendar.set(Calendar.SECOND, 0);
      calendar.set(Calendar.MILLISECOND, 0);
      calendar.add(Calendar.DAY_OF_MONTH, 1);
      return calendar.getTime();
    }

    private Date addDays(int amount) {
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(getDate());
      calendar.add(Calendar.DAY_OF_MONTH, amount);
      return calendar.getTime();
    }
  }

  public static void main(String[] args) {
    new Editar().setVisible(true);
  }
}
