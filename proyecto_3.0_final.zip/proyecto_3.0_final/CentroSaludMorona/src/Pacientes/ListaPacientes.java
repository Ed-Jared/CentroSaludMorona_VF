package Pacientes;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ListaPacientes extends JDialog {
  private static final long serialVersionUID = 1L;
  private final DefaultTableModel model;
  private final JTable table;

  public ListaPacientes(JDialog owner) {
    super(owner, "Lista de Pacientes", true);
    model =
        new DefaultTableModel(
            new String[] {
              "Nombres", "Apellidos", "DNI", "Edad", "Especialidad", "Medico", "Fecha", "Hora"
            }, 0) {
          public boolean isCellEditable(int r, int c) {
            return false;
          }
        };
    table = new JTable(model);
    build();
    refresh();
  }

  public ListaPacientes() {
    this(null);
  }

  private void build() {
    setBounds(100, 100, 760, 420);
    setLocationRelativeTo(getOwner());
    setLayout(new BorderLayout(8, 8));
    add(new JScrollPane(table), BorderLayout.CENTER);
    JButton clear = new JButton("Limpiar Lista");
    clear.setFont(new Font("Tahoma", Font.PLAIN, 15));
    clear.addActionListener(
        e -> {
          if (JOptionPane.showConfirmDialog(
                  this, "¿Borrar todos los pacientes?", "Confirmar", JOptionPane.YES_NO_OPTION)
              == JOptionPane.YES_OPTION) {
            AppData.clearPatients();
            refresh();
          }
        });
    JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    south.add(clear);
    add(south, BorderLayout.SOUTH);
  }

  private void refresh() {
    model.setRowCount(0);
    for (String[] p : AppData.patients()) {
      String[] row = p.clone();
      if (row.length > 7 && "0".equals(row[7])) row[7] = "No registrada";
      // The table order is: names, surnames, DNI, age, specialty, doctor, date, time.
      String[] tableRow = {row[0], row[1], row[2], row[7], row[3], row[4], row[5], row[6]};
      model.addRow(tableRow);
    }
  }

  public static void main(String[] args) {
    new ListaPacientes().setVisible(true);
  }
}
