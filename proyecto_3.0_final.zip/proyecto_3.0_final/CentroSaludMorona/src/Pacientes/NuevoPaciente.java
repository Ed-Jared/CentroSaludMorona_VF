package Pacientes;

import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import javax.swing.*;
import javax.swing.text.*;

public class NuevoPaciente extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextField dni = new JTextField(),
      names = new JTextField(),
      surnames = new JTextField(),
      age = new JTextField();
  private final JComboBox<String> specialty = new JComboBox<>();
  private final JComboBox<String> doctor = new JComboBox<>();
  private LocalDate selectedDate = LocalDate.now().plusDays(1);
  private final JTextField dateField = new JTextField();
  private LocalTime selectedTime = LocalTime.of(0, 0);
  private final JTextField timeField = new JTextField();
  private final JButton chooseDate = new JButton("Calendario");
  private final JButton chooseTime = new JButton("Hora");

  public NuevoPaciente(JDialog owner) {
    super(owner, "Nuevo Paciente", true);
    build();
  }

  public NuevoPaciente() {
    this(null);
  }

  private void build() {
    setBounds(100, 100, 430, 435);
    setLocationRelativeTo(getOwner());
    JPanel p = new JPanel(null);
    setContentPane(p);
    field(p, "DNI (8 dígitos):", dni, 20);
    field(p, "Nombres:", names, 60);
    field(p, "Apellidos:", surnames, 100);
    field(p, "Edad:", age, 140);
    ((AbstractDocument) age.getDocument()).setDocumentFilter(new Busqueda.AgeFilter(120, this));
    JLabel sl = label("Especialidad:", 180);
    p.add(sl);
    for (String s : AppData.specialties()) specialty.addItem(s);
    specialty.setBounds(150, 178, 230, 28);
    specialty.addActionListener(e -> loadDoctors());
    p.add(specialty);
    JLabel dl = label("Médico:", 220);
    p.add(dl);
    doctor.setBounds(150, 218, 230, 28);
    p.add(doctor);
    JLabel fl = label("Fecha:", 260);
    p.add(fl);
    dateField.setBounds(150, 258, 160, 28);
    dateField.setEditable(false);
    dateField.setText(selectedDate.format(AppData.DATE_FORMAT));
    p.add(dateField);
    chooseDate.setBounds(315, 258, 95, 28);
    chooseDate.addActionListener(e -> openDatePicker());
    p.add(chooseDate);
    JLabel tl = label("Hora:", 300);
    p.add(tl);
    timeField.setBounds(150, 298, 160, 28);
    timeField.setEditable(false);
    timeField.setText(selectedTime.toString());
    p.add(timeField);
    chooseTime.setBounds(315, 298, 95, 28);
    chooseTime.addActionListener(e -> openTimePicker());
    p.add(chooseTime);
    ((AbstractDocument) dni.getDocument()).setDocumentFilter(new Busqueda.DigitsFilter(8, this));
    Busqueda.addDniFocusValidation(dni, this);
    dni.setInputVerifier(Busqueda.dniCompleteVerifier(this));
    JButton save = new JButton("Guardar");
    save.setBounds(90, 355, 110, 32);
    save.addActionListener(e -> save());
    p.add(save);
    JButton cancel = new JButton("Cancelar");
    cancel.setBounds(225, 355, 110, 32);
    cancel.addActionListener(e -> dispose());
    p.add(cancel);
    loadDoctors();
    configureDniGate();
  }

  private void configureDniGate() {
    dni.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
      public void insertUpdate(javax.swing.event.DocumentEvent e) { update(); }
      public void removeUpdate(javax.swing.event.DocumentEvent e) { update(); }
      public void changedUpdate(javax.swing.event.DocumentEvent e) { update(); }
      private void update() { setDetailsEnabled(AppData.validDni(dni.getText())); }
    });
    setDetailsEnabled(AppData.validDni(dni.getText()));
  }

  private void setDetailsEnabled(boolean enabled) {
    names.setEnabled(enabled);
    surnames.setEnabled(enabled);
    age.setEnabled(enabled);
    specialty.setEnabled(enabled);
    doctor.setEnabled(enabled);
    dateField.setEnabled(enabled);
    timeField.setEnabled(enabled);
    chooseDate.setEnabled(enabled);
    chooseTime.setEnabled(enabled);
  }

  private JLabel label(String text, int y) {
    JLabel l = new JLabel(text);
    l.setBounds(20, y, 125, 28);
    return l;
  }

  private void field(JPanel p, String text, JTextField f, int y) {
    p.add(label(text, y));
    f.setBounds(150, y, 230, 28);
    p.add(f);
    if (f != dni) ((AbstractDocument) f.getDocument()).setDocumentFilter(new NameFilter());
  }

  private void loadDoctors() {
    doctor.removeAllItems();
    for (String d : AppData.doctorsFor((String) specialty.getSelectedItem())) doctor.addItem(d);
  }

  private void openDatePicker() {
    DatePickerDialo picker = new DatePickerDialo(this, selectedDate, this::onDateSelected);
    picker.setVisible(true);
  }

  private void onDateSelected(LocalDate value) {
    selectedDate = value;
    dateField.setText(selectedDate.format(AppData.DATE_FORMAT));
  }

  private void openTimePicker() {
    TimePickerDialog picker = new TimePickerDialog(this, selectedTime, this::onTimeSelected);
    picker.setVisible(true);
  }

  private void onTimeSelected(LocalTime value) {
    selectedTime = value;
    timeField.setText(selectedTime.toString());
  }

  String date() {
    return selectedDate.format(AppData.DATE_FORMAT);
  }

  private void save() {
    String d = dni.getText(), n = names.getText().trim(), s = surnames.getText().trim(), f = date();
    String ageText = age.getText().trim();
    if (!AppData.validDni(d)) {
      JOptionPane.showMessageDialog(this, "El DNI debe contener exactamente 8 números.");
      return;
    }
    if (!AppData.validAge(ageText)) {
      JOptionPane.showMessageDialog(this, "La edad debe ser un número entre 1 y 120 años.");
      return;
    }
    if (!AppData.validName(n) || !AppData.validName(s)) {
      JOptionPane.showMessageDialog(
          this, "Nombres y apellidos solo pueden contener letras y espacios.");
      return;
    }
    if (!AppData.validFutureDate(f)) {
      JOptionPane.showMessageDialog(this, "La fecha no puede ser anterior a hoy.");
      return;
    }
    if (AppData.findPatient(d) != null) {
      JOptionPane.showMessageDialog(this, "Ya existe un paciente con ese DNI.");
      return;
    }
    AppData.addPatient(
        new String[] {
          n, s, d, (String) specialty.getSelectedItem(), (String) doctor.getSelectedItem(), f,
          selectedTime.toString(), ageText
        });
    JOptionPane.showMessageDialog(this, "Paciente guardado correctamente.");
    dispose();
  }

  static class NameFilter extends DocumentFilter {
    public void insertString(FilterBypass fb, int o, String s, AttributeSet a)
        throws BadLocationException {
      replace(fb, o, 0, s, a);
    }

    public void replace(FilterBypass fb, int o, int l, String s, AttributeSet a)
        throws BadLocationException {
      if (s != null && s.matches("[\\p{L} ]*")) fb.replace(o, l, s, a);
    }
  }

  static class DailyDateModel extends SpinnerDateModel {
    private static final long serialVersionUID = 1L;

    DailyDateModel() {
      super(tomorrow(), tomorrow(), null, Calendar.DAY_OF_MONTH);
    }

    @Override
    public Object getNextValue() {
      return addDays(1);
    }

    @Override
    public Object getPreviousValue() {
      Date previous = addDays(-1);
      return previous.before((Date) getStart()) ? getStart() : previous;
    }

    private static Date tomorrow() {
      Calendar calendar = Calendar.getInstance();
      calendar.set(Calendar.HOUR_OF_DAY, 0);
      calendar.set(Calendar.MINUTE, 0);
      calendar.set(Calendar.SECOND, 0);
      calendar.set(Calendar.MILLISECOND, 0);
      calendar.add(Calendar.DAY_OF_MONTH, 1);
      return calendar.getTime();
    }

    private Date addDays(int amount) {
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(getDate());
      calendar.add(Calendar.DAY_OF_MONTH, amount);
      return calendar.getTime();
    }
  }

  public static void main(String[] args) {
    new NuevoPaciente().setVisible(true);
  }
}
