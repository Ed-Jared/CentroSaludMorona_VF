package Pacientes;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Paciente extends JDialog {
  private static final long serialVersionUID = 1L;
  private final String[] patient;

  public Paciente(JDialog owner, String[] patient) {
    super(owner, "Paciente", true);
    this.patient = patient;
    build();
  }

  public Paciente() {
    this(null, new String[] {"", "", "", "0", "", "", "", ""});
  }

  private void build() {
    setBounds(100, 100, 850, 250);
    setLocationRelativeTo(getOwner());
    setLayout(new BorderLayout(8, 8));
    DefaultTableModel m =
        new DefaultTableModel(
            new String[] {
              "Nombres", "Apellidos", "DNI", "Edad", "Especialidad", "Medico", "Fecha", "Hora"
            }, 0);
    String[] row = patient.clone();
    String age = row.length > 7 && !row[7].isBlank() && !"0".equals(row[7])
        ? row[7]
        : "No registrada";
    // AppData stores: names, surnames, DNI, specialty, doctor, date, time, age.
    // The table displays the same logical order as its headers.
    m.addRow(new String[] {
        row[0], row[1], row[2], age, row[3], row[4], row[5], row.length > 6 ? row[6] : "00:00"
    });
    JTable t = new JTable(m);
    t.setEnabled(false);
    add(new JScrollPane(t), BorderLayout.CENTER);
    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 25, 8));
    JButton edit = new JButton("Editar");
    edit.addActionListener(
        e -> {
          new Editar(this, patient).setVisible(true);
          dispose();
        });
    JButton delete = new JButton("Borrar");
    delete.addActionListener(
        e -> {
          if (JOptionPane.showConfirmDialog(
                  this, "¿Eliminar este paciente?", "Confirmar", JOptionPane.YES_NO_OPTION)
              == JOptionPane.YES_OPTION) {
            AppData.deletePatient(patient[2]);
            JOptionPane.showMessageDialog(this, "Paciente eliminado.");
            dispose();
          }
        });
    buttons.add(edit);
    buttons.add(delete);
    add(buttons, BorderLayout.SOUTH);
  }

  public static void main(String[] args) {
    new Paciente().setVisible(true);
  }
}
