package Pacientes;

import gui.Loby;
import java.awt.*;
import javax.swing.*;

public class Registro extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JFrame lobby;

  public Registro(JFrame lobby) {
    super(lobby, "Registro de pacientes", true);
    this.lobby = lobby;
    build();
  }

  public Registro() {
    this(null);
  }

  private void build() {
    setBounds(100, 100, 260, 280);
    setLocationRelativeTo(getOwner());
    JPanel p = new JPanel(null);
    setContentPane(p);
    JButton list = new JButton("Lista de pacientes");
    list.setBounds(35, 20, 175, 35);
    list.addActionListener(e -> new ListaPacientes(this).setVisible(true));
    p.add(list);
    JButton search = new JButton("Buscar Paciente");
    search.setBounds(35, 65, 175, 35);
    search.addActionListener(e -> new Busqueda(this).setVisible(true));
    p.add(search);
    JButton add = new JButton("Nuevo Paciente");
    add.setBounds(35, 110, 175, 35);
    add.addActionListener(e -> new NuevoPaciente(this).setVisible(true));
    p.add(add);
    JButton close = new JButton("Cerrar Sesión");
    close.setBounds(35, 165, 175, 35);
    close.addActionListener(
        e -> {
          JOptionPane.showMessageDialog(this, "La sesión se ha cerrado");
          dispose();
          if (lobby != null) lobby.setVisible(true);
          else new Loby().setVisible(true);
        });
    p.add(close);
    addWindowListener(
        new java.awt.event.WindowAdapter() {
          public void windowClosed(java.awt.event.WindowEvent e) {}
        });
  }

  public static void main(String[] args) {
    new Registro().setVisible(true);
  }
}
