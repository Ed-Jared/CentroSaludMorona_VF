package Pacientes;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.time.LocalTime;
import java.util.function.Consumer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class TimePickerDialo extends JDialog {

    private static final long serialVersionUID = 1L;

    private final Consumer<LocalTime> onSelected;

    private int hour;
    private int minute;

    private final JLabel hourLabel = new JLabel();
    private final JLabel minuteLabel = new JLabel();

    public TimePickerDialo(
            Window owner,
            LocalTime initialTime,
            Consumer<LocalTime> onSelected) {

        super(owner, "Seleccionar hora", ModalityType.APPLICATION_MODAL);

        LocalTime safeTime;

        if (initialTime == null) {
            safeTime = LocalTime.of(0, 0);
        } else {
            safeTime = initialTime;
        }

        this.hour = safeTime.getHour();
        this.minute = safeTime.getMinute();
        this.onSelected = onSelected;

        construirVentana();
        actualizarEtiquetas();
    }

    private void construirVentana() {

        setSize(260, 230);
        setLocationRelativeTo(getOwner());
        setLayout(new BorderLayout(8, 8));

        JLabel titulo = new JLabel(
                "Elige la hora de la cita",
                SwingConstants.CENTER);

        titulo.setBorder(
                BorderFactory.createEmptyBorder(10, 5, 0, 5));

        add(titulo, BorderLayout.NORTH);

        JPanel columnas = new JPanel(
                new GridLayout(1, 2, 12, 0));

        columnas.add(
                crearColumna(
                        "Horas",
                        hourLabel,
                        true));

        columnas.add(
                crearColumna(
                        "Minutos",
                        minuteLabel,
                        false));

        add(columnas, BorderLayout.CENTER);

        JPanel botones = new JPanel();

        JButton aceptar = new JButton("Aceptar");

        aceptar.addActionListener(e -> {

            LocalTime horaSeleccionada =
                    LocalTime.of(hour, minute);

            onSelected.accept(horaSeleccionada);

            dispose();
        });

        JButton cancelar = new JButton("Cancelar");

        cancelar.addActionListener(e -> dispose());

        botones.add(aceptar);
        botones.add(cancelar);

        add(botones, BorderLayout.SOUTH);
    }

    private JPanel crearColumna(
            String titulo,
            JLabel etiqueta,
            boolean esHora) {

        JPanel columna = new JPanel(
                new BorderLayout(3, 3));

        JLabel tituloColumna = new JLabel(
                titulo,
                SwingConstants.CENTER);

        columna.add(
                tituloColumna,
                BorderLayout.NORTH);

        JButton subir = new JButton("▲");

        subir.addActionListener(e -> {

            if (esHora) {
                hour = (hour + 1) % 24;
            } else {
                minute = (minute + 1) % 60;
            }

            actualizarEtiquetas();
        });

        JButton bajar = new JButton("▼");

        bajar.addActionListener(e -> {

            if (esHora) {
                hour = (hour + 23) % 24;
            } else {
                minute = (minute + 59) % 60;
            }

            actualizarEtiquetas();
        });

        etiqueta.setHorizontalAlignment(
                SwingConstants.CENTER);

        etiqueta.setFont(
                etiqueta.getFont().deriveFont(24f));

        JPanel flechas = new JPanel(
                new GridLayout(3, 1, 2, 2));

        flechas.add(subir);
        flechas.add(etiqueta);
        flechas.add(bajar);

        columna.add(
                flechas,
                BorderLayout.CENTER);

        return columna;
    }

    private void actualizarEtiquetas() {

        hourLabel.setText(
                String.format("%02d", hour));

        minuteLabel.setText(
                String.format("%02d", minute));
    }
}
