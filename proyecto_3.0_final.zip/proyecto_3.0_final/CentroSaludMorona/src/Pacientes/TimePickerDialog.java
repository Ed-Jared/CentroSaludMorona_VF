package Pacientes;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.time.LocalTime;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class TimePickerDialog extends JDialog {
  private static final long serialVersionUID = 1L;
  private final Consumer<LocalTime> onSelected;
  private int hour;
  private int minute;
  private final JLabel hourLabel = new JLabel();
  private final JLabel minuteLabel = new JLabel();

  public TimePickerDialog(Window owner, LocalTime initialTime, Consumer<LocalTime> onSelected) {
    super(owner, "Seleccionar hora", ModalityType.APPLICATION_MODAL);
    LocalTime safeTime = initialTime == null ? LocalTime.of(0, 0) : initialTime;
    this.hour = safeTime.getHour();
    this.minute = safeTime.getMinute();
    this.onSelected = onSelected;
    build();
    refreshLabels();
  }

  private void build() {
    setSize(260, 230);
    setLocationRelativeTo(getOwner());
    setLayout(new BorderLayout(8, 8));
    JLabel title = new JLabel("Elige la hora de la cita", SwingConstants.CENTER);
    title.setBorder(BorderFactory.createEmptyBorder(10, 5, 0, 5));
    add(title, BorderLayout.NORTH);

    JPanel columns = new JPanel(new GridLayout(1, 2, 12, 0));
    columns.add(createColumn("Horas", hourLabel, true));
    columns.add(createColumn("Minutos", minuteLabel, false));
    add(columns, BorderLayout.CENTER);

    JPanel buttons = new JPanel();
    JButton accept = new JButton("Aceptar");
    accept.addActionListener(e -> {
      onSelected.accept(LocalTime.of(hour, minute));
      dispose();
    });
    JButton cancel = new JButton("Cancelar");
    cancel.addActionListener(e -> dispose());
    buttons.add(accept);
    buttons.add(cancel);
    add(buttons, BorderLayout.SOUTH);
  }

  private JPanel createColumn(String title, JLabel valueLabel, boolean hours) {
    JPanel column = new JPanel(new BorderLayout(3, 3));
    column.add(new JLabel(title, SwingConstants.CENTER), BorderLayout.NORTH);
    JButton up = new JButton("▲");
    up.addActionListener(e -> {
      if (hours) hour = (hour + 1) % 24;
      else minute = (minute + 1) % 60;
      refreshLabels();
    });
    JButton down = new JButton("▼");
    down.addActionListener(e -> {
      if (hours) hour = (hour + 23) % 24;
      else minute = (minute + 59) % 60;
      refreshLabels();
    });
    valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
    valueLabel.setFont(valueLabel.getFont().deriveFont(24f));
    JPanel arrows = new JPanel(new GridLayout(3, 1, 2, 2));
    arrows.add(up);
    arrows.add(valueLabel);
    arrows.add(down);
    column.add(arrows, BorderLayout.CENTER);
    return column;
  }

  private void refreshLabels() {
    hourLabel.setText(String.format("%02d", hour));
    minuteLabel.setText(String.format("%02d", minute));
  }
}
