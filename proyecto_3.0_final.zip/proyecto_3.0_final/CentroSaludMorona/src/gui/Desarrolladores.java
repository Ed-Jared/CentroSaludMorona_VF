package gui;

import java.awt.*;
import javax.swing.*;

public class Desarrolladores extends JDialog {
  private static final long serialVersionUID = 1L;

  public Desarrolladores(Frame owner) {
    super(owner, "Desarrolladores", true);
    build();
  }

  public Desarrolladores() {
    this((Frame) null);
  }

  private void build() {
    setBounds(100, 100, 670, 580);
    setLocationRelativeTo(getOwner());
    JPanel p = new JPanel(new GridLayout(2, 3, 12, 12));
    p.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    String[] images = {
      "/imagenes/1.png", "/imagenes/4.png", "/imagenes/2.png", "/imagenes/5.png", "/imagenes/3.png"
    };
    String[] names = {
      "Edwin Villanueva\nEfio\nN00544966",
      "Andy Anderson\nAguirre\nN00535438",
      "Jonatan Niño\nDurand\nN00531464",
      "David Siancas\nHerrera\nN00532550",
      "Kevin Pacora\nSotelo\nN00529081"
    };
    for (int i = 0; i < images.length; i++) {
      JPanel card = new JPanel(new BorderLayout());
      JLabel pic = new JLabel(new ImageIcon(Desarrolladores.class.getResource(images[i])));
      pic.setHorizontalAlignment(SwingConstants.CENTER);
      card.add(pic, BorderLayout.CENTER);
      JTextArea text = new JTextArea(names[i].replace("\\n", "\n"));
      text.setEditable(false);
      text.setOpaque(false);
      text.setFont(new Font("Dialog", Font.PLAIN, 12));
      card.add(text, BorderLayout.SOUTH);
      p.add(card);
    }
    add(p);
  }

  public static void main(String[] args) {
    new Desarrolladores().setVisible(true);
  }
}
