package gui;

import Pacientes.AppData;
import Pacientes.Registro;
import java.awt.*;
import javax.swing.*;

public class IniciarSesion extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextField user = new JTextField();
  private final JPasswordField password = new JPasswordField();
  private int attempts;
  private final JFrame lobby;

  public IniciarSesion(JFrame lobby) {
    super(lobby, "Iniciar Sesión", true);
    this.lobby = lobby;
    build();
  }

  public IniciarSesion() {
    this(null);
  }

  private void build() {
    AppData.ensureFiles();
    setBounds(100, 100, 330, 220);
    setLocationRelativeTo(getOwner());
    JPanel p = new JPanel(null);
    setContentPane(p);
    p.add(label("Usuario(a):", 15, 20));
    user.setBounds(105, 18, 185, 26);
    p.add(user);
    p.add(label("Contraseña:", 15, 58));
    password.setBounds(105, 56, 185, 26);
    p.add(password);
    JButton login = new JButton("Iniciar Sesión");
    login.setBounds(90, 98, 140, 30);
    login.addActionListener(e -> login());
    p.add(login);
    JButton register = new JButton("Registrarse");
    register.setBounds(90, 138, 140, 30);
    register.addActionListener(
        e -> {
          new NuevoEnfermero_a(this).setVisible(true);
        });
    p.add(register);
    getRootPane().setDefaultButton(login);
  }

  private JLabel label(String s, int x, int y) {
    JLabel l = new JLabel(s);
    l.setBounds(x, y, 90, 25);
    return l;
  }

  private void login() {
    String saved = AppData.findNurse(user.getText().trim());
    if (saved != null && saved.equals(new String(password.getPassword()))) {
      dispose();
      new Registro(lobby).setVisible(true);
      return;
    }
    attempts++;
    String subject = saved == null ? "Usuario" : "Contraseña";
    if (attempts >= 3) {
      JOptionPane.showMessageDialog(
          this, subject + " es incorrecto. Por favor vuelve a intentarlo más tarde");
      dispose();
      return;
    }
    JOptionPane.showMessageDialog(this, subject + " incorrecto. Intento " + attempts + " de 3");
  }

  public static void main(String[] args) {
    new IniciarSesion().setVisible(true);
  }
}
