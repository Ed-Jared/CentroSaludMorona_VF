package gui;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import medico.Medico;

public class Loby extends JFrame {
  private static final long serialVersionUID = 1L;

  public static void main(String[] args) {
    EventQueue.invokeLater(() -> new Loby().setVisible(true));
  }

  public Loby() {
    setTitle("Centro de Salud Morona");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 340, 285);
    setLocationByPlatform(true);
    JMenuBar bar = new JMenuBar();
    JMenu menu = new JMenu("Programadores");
    JMenuItem developers = new JMenuItem("Desarrolladores");
    developers.addActionListener(e -> new Desarrolladores(this).setVisible(true));
    menu.add(developers);
    bar.add(menu);
    setJMenuBar(bar);
    JPanel panel = new JPanel(null);
    panel.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(panel);
    JTextArea title = new JTextArea("CENTRO DE SALUD\n    MORONA");
    title.setEditable(false);
    title.setFont(new Font("Monospaced", Font.BOLD, 20));
    title.setBounds(55, 20, 220, 60);
    panel.add(title);
    JButton login = new JButton("LOGIN");
    login.setFont(new Font("Tahoma", Font.PLAIN, 15));
    login.setBounds(90, 105, 140, 36);
    login.addActionListener(e -> new IniciarSesion(this).setVisible(true));
    panel.add(login);
    JButton medicalLogin = new JButton("ACCESO MÉDICO");
    medicalLogin.setFont(new Font("Tahoma", Font.PLAIN, 14));
    medicalLogin.setBounds(62, 159, 196, 36);
    medicalLogin.addActionListener(e -> new Medico(this).setVisible(true));
    panel.add(medicalLogin);
  }
}
