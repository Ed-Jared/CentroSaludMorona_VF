package gui;

import Pacientes.AppData;
import java.awt.*;
import javax.swing.*;

public class NuevoEnfermero_a extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextField user = new JTextField();
  private final JPasswordField password = new JPasswordField();
  private final JPasswordField confirmPassword = new JPasswordField();
  private final JDialog login;

  public NuevoEnfermero_a(JDialog login) {
    super(login, "Nuevo enfermero/a", true);
    this.login = login;
    build();
  }

  public NuevoEnfermero_a() {
    this(null);
  }

  private void build() {
    setBounds(100, 100, 360, 250);
    setLocationRelativeTo(getOwner());
    JPanel p = new JPanel(null);
    setContentPane(p);
    JLabel u = new JLabel("Usuario:");
    u.setBounds(15, 25, 90, 25);
    p.add(u);
    user.setBounds(110, 23, 210, 28);
    p.add(user);
    JLabel pass = new JLabel("Contraseña:");
    pass.setBounds(15, 65, 90, 25);
    p.add(pass);
    password.setBounds(110, 63, 210, 28);
    p.add(password);
    JLabel confirm = new JLabel("Confirmar:");
    confirm.setBounds(15, 105, 90, 25);
    p.add(confirm);
    confirmPassword.setBounds(110, 103, 210, 28);
    p.add(confirmPassword);
    JButton save = new JButton("Guardar");
    save.setBounds(115, 155, 110, 30);
    save.addActionListener(e -> save());
    p.add(save);
    getRootPane().setDefaultButton(save);
  }

  private void save() {
    String u = user.getText().trim();
    String p = new String(password.getPassword());
    String confirmation = new String(confirmPassword.getPassword());
    if (u.isBlank()) {
      JOptionPane.showMessageDialog(this, "Escribe un usuario.");
      return;
    }
    if (!AppData.validName(u)) {
      JOptionPane.showMessageDialog(this, "El usuario solo puede contener letras y espacios.");
      return;
    }
    if (p.isBlank()) {
      JOptionPane.showMessageDialog(this, "Escribe una contraseña.");
      return;
    }
    if (p.contains("|") || p.contains("\n") || p.contains("\r")) {
      JOptionPane.showMessageDialog(this, "La contraseña contiene caracteres no permitidos.");
      return;
    }
    if (!p.equals(confirmation)) {
      JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden.");
      return;
    }
    if (!AppData.addNurse(u, p)) {
      JOptionPane.showMessageDialog(this, "Ese usuario ya está registrado.");
      return;
    }
    JOptionPane.showMessageDialog(this, "Enfermero/a guardado correctamente.");
    dispose();
  }

  public static void main(String[] args) {
    new NuevoEnfermero_a().setVisible(true);
  }
}
