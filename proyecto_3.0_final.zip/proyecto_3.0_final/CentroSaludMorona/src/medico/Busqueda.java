package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class Busqueda extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextArea dni = new JTextArea();
  private final util.Medico medico;

  public Busqueda(Window owner, util.Medico m) {
    super(owner, "Búsqueda de Pacientes", ModalityType.APPLICATION_MODAL);
    medico = m;
    setSize(300, 170);
    setLocationRelativeTo(owner);
    JPanel p = new JPanel(null);
    setContentPane(p);
    JLabel l = new JLabel("DNI:");
    l.setBounds(20, 30, 60, 25);
    p.add(l);
    dni.setBounds(80, 30, 180, 25);
    Util.limitarDni(dni, this);
    p.add(dni);
    JButton b = new JButton("BUSCAR");
    b.setBounds(90, 80, 110, 30);
    p.add(b);
    b.addActionListener(e -> buscar());
  }

  public Busqueda() {
    this(null, new util.Medico("", "", ""));
  }

  private void buscar() {
    if (!Util.dniValido(dni.getText().trim())) {
      Util.error(this, "El DNI tiene que tener 8 caracteres");
      return;
    }
    try {
      Paciente p = ArchivoDatos.paciente(dni.getText().trim());
      if (p == null) {
        Util.error(this, "Paciente no encontrado");
        return;
      }
      dispose();
      new PacienteHallado(getOwner(), p, medico).setVisible(true);
    } catch (Exception e) {
      Util.error(this, "No se pudo buscar el paciente");
    }
  }
}
