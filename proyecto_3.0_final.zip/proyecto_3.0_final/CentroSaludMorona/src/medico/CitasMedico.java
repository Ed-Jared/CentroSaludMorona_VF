package medico;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import util.*;

public class CitasMedico extends JDialog {
  private static final long serialVersionUID = 1L;
  private final DefaultTableModel model =
      new DefaultTableModel(
          new String[] {"Nombres", "Apellidos", "DNI", "Especialidad", "Edad", "Fecha", "Hora"}, 0);
  private final util.Medico medico;

  public CitasMedico(Window owner, util.Medico m) {
    super(owner, "Citas Programadas", ModalityType.APPLICATION_MODAL);
    medico = m;
    setSize(930, 390);
    setLocationRelativeTo(owner);
    JPanel p = new JPanel(new BorderLayout(8, 8));
    p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    setContentPane(p);
    p.add(new JScrollPane(new JTable(model)), BorderLayout.CENTER);
    JPanel buttons = new JPanel();
    JButton buscar = new JButton("Buscar"),
        editar = new JButton("Editar"),
        eliminar = new JButton("Eliminar");
    buttons.add(buscar);
    buttons.add(editar);
    buttons.add(eliminar);
    p.add(buttons, BorderLayout.SOUTH);
    cargar();
    buscar.addActionListener(e -> new Busqueda(this, medico).setVisible(true));
    editar.addActionListener(e -> new Edicion(this, medico, this::cargar).setVisible(true));
    eliminar.addActionListener(e -> new Eliminar(this, this::cargar).setVisible(true));
  }

  public CitasMedico() {
    this(null, new util.Medico("", "", ""));
  }

  private void cargar() {
    model.setRowCount(0);
    try {
      List<util.Medico> delArea = ArchivoDatos.medicosPorEspecialidad(medico.getEspecialidad());
      boolean soloArea = delArea.size() <= 1;
      for (Paciente x : ArchivoDatos.pacientes()) {
        boolean coincide =
            x.getEspecialidad().equals(medico.getEspecialidad())
                && (soloArea || medico.getUsuario().equals(x.getDoctor()));
        if (coincide)
          model.addRow(
              new Object[] {
                x.getNombres(),
                x.getApellidos(),
                x.getDni(),
                x.getEspecialidad(),
                x.getEdad() > 0 ? x.getEdad() : "No registrada",
                x.getFecha(),
                x.getHora()
              });
      }
    } catch (Exception e) {
      Util.error(this, "No se pudieron cargar las citas");
    }
  }
}
