package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class Edicion extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextArea dni = new JTextArea();
  private final util.Medico medico;
  private final Runnable callback;

  public Edicion(Window owner, util.Medico m, Runnable cb) {
    super(owner, "Editar paciente", ModalityType.APPLICATION_MODAL);
    medico = m;
    callback = cb;
    setSize(300, 170);
    setLocationRelativeTo(owner);
    JPanel p = new JPanel(null);
    setContentPane(p);
    JLabel l = new JLabel("DNI:");
    l.setBounds(20, 30, 60, 25);
    p.add(l);
    dni.setBounds(80, 30, 180, 25);
    Util.limitarDni(dni, this);
    p.add(dni);
    JButton b = new JButton("Editar");
    b.setBounds(95, 80, 100, 30);
    p.add(b);
    b.addActionListener(e -> buscar());
  }

  public Edicion(Window owner, util.Medico m) {
    this(owner, m, null);
  }

  public Edicion() {
    this(null, new util.Medico("", "", ""), null);
  }

  private void buscar() {
    String d = dni.getText().trim();
    if (!Util.dniValido(d)) {
      Util.error(this, "El DNI tiene que tener 8 caracteres");
      return;
    }
    try {
      Paciente p = ArchivoDatos.paciente(d);
      if (p == null) {
        Util.error(this, "Paciente no encontrado");
        return;
      }
      dispose();
      new EditarPaciente(getOwner(), p, callback).setVisible(true);
    } catch (Exception e) {
      Util.error(this, "No se pudo buscar el paciente");
    }
  }
}
