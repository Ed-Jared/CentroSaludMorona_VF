package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class EditarPaciente extends JDialog {
  private static final long serialVersionUID = 1L;
  private final Paciente original;
  private final Runnable callback;
  private final JTextArea dni = new JTextArea(), nom = new JTextArea(), ape = new JTextArea();

  public EditarPaciente(Window owner, Paciente p, Runnable cb) {
    super(owner, "Editar Paciente", ModalityType.APPLICATION_MODAL);
    original = p;
    callback = cb;
    setSize(300, 230);
    setLocationRelativeTo(owner);
    JPanel pan = new JPanel(null);
    setContentPane(pan);
    add(pan, "DNI:", dni, 20, 20);
    add(pan, "Nombres:", nom, 20, 55);
    add(pan, "Apellidos:", ape, 20, 90);
    JButton b = new JButton("Finalizar Edición");
    b.setBounds(75, 140, 145, 32);
    pan.add(b);
    dni.setText(p.getDni());
    nom.setText(p.getNombres());
    ape.setText(p.getApellidos());
    b.addActionListener(e -> guardar());
  }

  private void add(JPanel p, String s, JTextArea t, int x, int y) {
    JLabel l = new JLabel(s);
    l.setBounds(x, y, 80, 25);
    p.add(l);
    t.setBounds(100, y, 170, 25);
    p.add(t);
  }

  private void guardar() {
    String nd = dni.getText().trim();
    if (!Util.dniValido(nd)) {
      Util.error(this, "El DNI tiene que tener 8 caracteres");
      return;
    }
    try {
      Paciente otro = ArchivoDatos.paciente(nd);
      if (otro != null && !nd.equals(original.getDni())) {
        Util.error(this, "Este DNI ya fue registrado. Por favor intentar de nuevo");
        return;
      }
      Paciente n =
          new Paciente(
              nd,
              nom.getText().trim(),
              ape.getText().trim(),
              original.getEdad(),
              original.getEspecialidad(),
              original.getDoctor(),
              original.getFecha(),
              original.getHora());
      ArchivoDatos.reemplazarPaciente(original.getDni(), n);
      original.setDni(nd);
      original.setNombres(n.getNombres());
      original.setApellidos(n.getApellidos());
      Util.info(this, "Paciente actualizado correctamente");
      if (callback != null) callback.run();
      dispose();
    } catch (Exception e) {
      Util.error(this, "No se pudo guardar la edición");
    }
  }
}
