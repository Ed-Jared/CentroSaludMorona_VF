package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class Eliminar extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextArea dni = new JTextArea();
  private final Runnable callback;

  public Eliminar(Window owner, Runnable cb) {
    super(owner, "Eliminar paciente", ModalityType.APPLICATION_MODAL);
    callback = cb;
    setSize(300, 170);
    setLocationRelativeTo(owner);
    JPanel p = new JPanel(null);
    setContentPane(p);
    JLabel l = new JLabel("DNI:");
    l.setBounds(20, 30, 60, 25);
    p.add(l);
    dni.setBounds(80, 30, 180, 25);
    p.add(dni);
    JButton b = new JButton("ELIMINAR");
    b.setBounds(85, 80, 120, 30);
    p.add(b);
    b.addActionListener(e -> eliminar());
  }

  public Eliminar(Window owner) {
    this(owner, null);
  }

  public Eliminar() {
    this(null, null);
  }

  private void eliminar() {
    String d = dni.getText().trim();
    if (!Util.dniValido(d)) {
      Util.error(this, "El DNI tiene que tener 8 caracteres");
      return;
    }
    try {
      if (!ArchivoDatos.eliminarPaciente(d)) {
        Util.error(this, "Paciente no encontrado");
        return;
      }
      Util.info(this, "Paciente eliminado correctamente");
      if (callback != null) callback.run();
      dispose();
    } catch (Exception e) {
      Util.error(this, "No se pudo eliminar el paciente");
    }
  }
}
