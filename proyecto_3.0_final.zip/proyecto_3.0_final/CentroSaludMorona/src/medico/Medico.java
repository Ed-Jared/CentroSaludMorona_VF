package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class Medico extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextArea usuario = new JTextArea();
  private final JPasswordField contrasena = new JPasswordField();
  private int intentosFallidos = 0;

  public Medico(Window owner) {
    super(owner, "Iniciar sesión médico", ModalityType.APPLICATION_MODAL);
    setSize(300, 230);
    setLocationRelativeTo(owner);
    JPanel p = new JPanel(null);
    setContentPane(p);
    label(p, "Usuario:", 20, 25);
    field(p, usuario, 105, 23);
    label(p, "Contraseña:", 20, 65);
    field(p, contrasena, 105, 63);
    JButton entrar = new JButton("Iniciar Sesión"), nuevo = new JButton("Nuevo Registro");
    entrar.setBounds(75, 105, 140, 32);
    nuevo.setBounds(75, 150, 140, 28);
    p.add(entrar);
    p.add(nuevo);
    entrar.addActionListener(e -> entrar());
    nuevo.addActionListener(e -> new NuevoMedico(this).setVisible(true));
  }

  public Medico() {
    this(null);
  }

  private void entrar() {
    try {
      util.Medico m = ArchivoDatos.medico(usuario.getText().trim(), new String(contrasena.getPassword()));
      if (m == null) {
        intentosFallidos++;
        if (intentosFallidos < 3) {
          Util.error(this, "No se ha podido Iniciar de Sesión, vuelva a intentarlo");
        } else {
          Util.error(this, "Ya se usaron los 3 intentos, pruebe mas tarde");
          dispose();
        }
        return;
      }
      dispose();
      new CitasMedico(getOwner(), m).setVisible(true);
    } catch (Exception e) {
      Util.error(this, "No se ha podido Iniciar de Sesión, vuelva a intentarlo");
    }
  }

  private static void label(JPanel p, String s, int x, int y) {
    JLabel l = new JLabel(s);
    l.setBounds(x, y, 90, 25);
    p.add(l);
  }

  private static void field(JPanel p, javax.swing.text.JTextComponent t, int x, int y) {
    t.setBounds(x, y, 160, 25);
    p.add(t);
  }
}
