package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class NuevoMedico extends JDialog {
  private static final long serialVersionUID = 1L;
  private final JTextArea usuario = new JTextArea();
  private final JPasswordField contrasena = new JPasswordField();
  private final JComboBox<String> especialidad = Util.especialidades();

  public NuevoMedico(Window owner) {
    super(owner, "Nuevo Médico", ModalityType.APPLICATION_MODAL);
    setSize(360, 250);
    setLocationRelativeTo(owner);
    JPanel p = new JPanel(null);
    setContentPane(p);
    label(p, "Usuario:", 20, 25);
    usuario.setBounds(115, 23, 210, 25);
    p.add(usuario);
    label(p, "Especialidad:", 20, 65);
    especialidad.setBounds(115, 63, 210, 25);
    p.add(especialidad);
    label(p, "Contraseña:", 20, 105);
    contrasena.setBounds(115, 103, 210, 25);
    p.add(contrasena);
    JButton b = new JButton("Finalizar Registro");
    b.setBounds(105, 150, 155, 32);
    p.add(b);
    b.addActionListener(e -> guardar());
  }

  public NuevoMedico() {
    this(null);
  }

  private void guardar() {
    String u = usuario.getText().trim();
    if (u.isEmpty()) {
      Util.error(this, "Ingrese un usuario");
      return;
    }
    String clave = new String(contrasena.getPassword());
    if (clave.isBlank()) {
      Util.error(this, "Ingrese una contraseña");
      return;
    }
    if (clave.contains("|") || clave.contains("\n") || clave.contains("\r")) {
      Util.error(this, "La contraseña contiene caracteres no permitidos");
      return;
    }
    try {
      if (ArchivoDatos.existeMedico(u)) {
        Util.error(this, "Este usuario ya fue registrado");
        return;
      }
      int nuevos = Math.max(0, ArchivoDatos.medicos().size() - 5);
      if (nuevos >= Util.MAX_MEDICOS_NUEVOS) {
        Util.error(this, "Se alcanzó el límite de 5 médicos nuevos");
        return;
      }
      ArchivoDatos.guardarMedico(
          new util.Medico(u, (String) especialidad.getSelectedItem(), clave));
      Util.info(this, "Médico registrado correctamente");
      dispose();
    } catch (Exception e) {
      Util.error(this, "No se pudo guardar el médico");
    }
  }

  private static void label(JPanel p, String s, int x, int y) {
    JLabel l = new JLabel(s);
    l.setBounds(x, y, 95, 25);
    p.add(l);
  }
}
