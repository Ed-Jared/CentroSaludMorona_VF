package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class PacienteHallado extends JDialog {
  private static final long serialVersionUID = 1L;
  private final Paciente paciente;
  private final util.Medico medico;
  private final JTextArea receta = new JTextArea();

  public PacienteHallado(Window owner, Paciente p, util.Medico m) {
    super(owner, "Paciente Hallado", ModalityType.APPLICATION_MODAL);
    paciente = p;
    medico = m;
    setSize(390, 390);
    setLocationRelativeTo(owner);
    JPanel pan = new JPanel(null);
    setContentPane(pan);
    int y = 20;
    y = valor(pan, "DNI:", p.getDni(), y);
    y = valor(pan, "Nombres:", p.getNombres(), y);
    y = valor(pan, "Apellidos:", p.getApellidos(), y);
    y = valor(pan, "Edad:", String.valueOf(p.getEdad()), y);
    y = valor(pan, "Especialidad:", p.getEspecialidad(), y);
    y = valor(pan, "Médico:", p.getDoctor(), y);
    y = valor(pan, "Fecha de cita:", p.getFecha(), y);
    y = valor(pan, "Hora de cita:", p.getHora(), y);
    JLabel r = new JLabel("Receta Médica:");
    r.setBounds(20, y, 110, 25);
    pan.add(r);
    receta.setLineWrap(true);
    receta.setWrapStyleWord(true);
    receta.setBounds(130, y, 220, 70);
    pan.add(receta);
    JButton b = new JButton("Generar Ticket");
    b.setBounds(125, y + 90, 140, 32);
    pan.add(b);
    b.addActionListener(e -> generar());
  }

  private int valor(JPanel p, String a, String v, int y) {
    JLabel l = new JLabel(a);
    l.setBounds(20, y, 110, 25);
    p.add(l);
    JTextField f = new JTextField(v);
    f.setEditable(false);
    f.setBounds(130, y, 220, 25);
    p.add(f);
    return y + 32;
  }

  private void generar() {
    try {
      String fechaTicket = ArchivoDatos.ahora();
      util.Ticket t =
          new util.Ticket(
              paciente.getDni(),
              paciente.getNombres() + " " + paciente.getApellidos(),
              medico.getUsuario(),
              medico.getEspecialidad(),
              receta.getText().trim(),
              fechaTicket);
      ArchivoDatos.guardarTicket(t);
      dispose();
      new medico.Ticket(getOwner(), t).setVisible(true);
    } catch (Exception e) {
      Util.error(this, "No se pudo generar el ticket");
    }
  }
}
