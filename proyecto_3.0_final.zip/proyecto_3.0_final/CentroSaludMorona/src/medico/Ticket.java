package medico;

import java.awt.*;
import javax.swing.*;
import util.*;

public class Ticket extends JDialog {
  private static final long serialVersionUID = 1L;

  public Ticket(Window owner, util.Ticket t) {
    super(owner, "Ticket", ModalityType.APPLICATION_MODAL);
    setSize(360, 330);
    setLocationRelativeTo(owner);
    JTextArea area = new JTextArea();
    area.setEditable(false);
    area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
    area.setText(
        "CENTRO DE SALUD MORONA\n=========================\nPaciente: "
            + t.getPaciente()
            + "\nDNI: "
            + t.getDni()
            + "\nMédico: "
            + t.getMedico()
            + "\nEspecialidad: "
            + t.getEspecialidad()
            + "\nFecha: "
            + t.getFecha()
            + "\n\nRECETA MÉDICA:\n"
            + t.getReceta());
    add(new JScrollPane(area));
  }

  public Ticket() {
    this(null, new util.Ticket("", "", "", "", "", ""));
  }
}
