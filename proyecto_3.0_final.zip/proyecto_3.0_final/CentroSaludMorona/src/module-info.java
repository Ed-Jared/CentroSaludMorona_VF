/** */
/** */
module CentroSaludMorona {
  requires java.desktop;
}
