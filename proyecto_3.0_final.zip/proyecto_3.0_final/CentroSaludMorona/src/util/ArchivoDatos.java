package util;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import Pacientes.AppData;

public final class ArchivoDatos {
  private ArchivoDatos() {}
  public static synchronized List<Paciente> pacientes() {
    List<Paciente> r = new ArrayList<>();
    for (String[] p : AppData.patients()) {
      if (p.length >= 8) {
        int edad = 0;
        try { edad = Integer.parseInt(p[7]); } catch (NumberFormatException ignored) {}
        r.add(new Paciente(p[2], p[0], p[1], edad, p[3], p[4], p[5], p[6]));
      }
    }
    return r;
  }
  public static Paciente paciente(String dni) { for(Paciente p: pacientes()) if(p.getDni().equals(dni)) return p; return null; }
  public static void reemplazarPaciente(String anterior, Paciente p) { AppData.updatePatient(anterior,new String[]{p.getNombres(),p.getApellidos(),p.getDni(),p.getEspecialidad(),p.getDoctor(),p.getFecha(),p.getHora(),String.valueOf(p.getEdad())}); }
  public static boolean eliminarPaciente(String dni) { return AppData.deletePatient(dni); }
  public static List<Medico> medicos() { List<Medico> r=new ArrayList<>(); for(String[] p:AppData.doctors()) r.add(new Medico(p[0],p[1],p[2])); return r; }
  public static List<Medico> medicosPorEspecialidad(String e) { List<Medico> r=new ArrayList<>(); for(Medico m:medicos()) if(m.getEspecialidad().equals(e)) r.add(m); return r; }
  public static Medico medico(String u,String c) { for(Medico m:medicos()) if(m.getUsuario().equalsIgnoreCase(u)&&m.getContrasena().equals(c)) return m; return null; }
  public static boolean existeMedico(String u) { for(Medico m:medicos()) if(m.getUsuario().equalsIgnoreCase(u)) return true; return false; }
  public static void guardarMedico(Medico m) { AppData.addDoctor(m.getUsuario(),m.getEspecialidad(),m.getContrasena()); }
  public static String ahora() { return LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")); }
  public static void guardarTicket(Ticket t) throws IOException { }
}
