package util;
public class Medico {
  private final String usuario, especialidad, contrasena;
  public Medico(String usuario, String especialidad, String contrasena) { this.usuario=usuario; this.especialidad=especialidad; this.contrasena=contrasena; }
  public String getUsuario(){return usuario;} public String getEspecialidad(){return especialidad;} public String getContrasena(){return contrasena;}
}
