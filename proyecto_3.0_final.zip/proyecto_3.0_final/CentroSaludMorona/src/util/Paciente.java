package util;
public class Paciente {
  private String dni,nombres,apellidos,especialidad,doctor,fecha,hora; private int edad;
  public Paciente(String dni,String nombres,String apellidos,int edad,String especialidad,String doctor,String fecha,String hora){this.dni=dni;this.nombres=nombres;this.apellidos=apellidos;this.edad=edad;this.especialidad=especialidad;this.doctor=doctor;this.fecha=fecha;this.hora=hora==null||hora.isBlank()?"00:00":hora;}
  public String getDni(){return dni;} public void setDni(String v){dni=v;} public String getNombres(){return nombres;} public void setNombres(String v){nombres=v;} public String getApellidos(){return apellidos;} public void setApellidos(String v){apellidos=v;} public int getEdad(){return edad;} public String getEspecialidad(){return especialidad;} public String getDoctor(){return doctor;} public String getFecha(){return fecha;} public String getHora(){return hora;}
}
