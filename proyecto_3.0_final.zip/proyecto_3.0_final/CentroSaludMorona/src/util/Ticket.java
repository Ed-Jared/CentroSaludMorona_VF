package util;
public class Ticket {
  private final String dni,paciente,medico,especialidad,receta,fecha;
  public Ticket(String dni,String paciente,String medico,String especialidad,String receta,String fecha){this.dni=dni;this.paciente=paciente;this.medico=medico;this.especialidad=especialidad;this.receta=receta;this.fecha=fecha;}
  public String getDni(){return dni;} public String getPaciente(){return paciente;} public String getMedico(){return medico;} public String getEspecialidad(){return especialidad;} public String getReceta(){return receta;} public String getFecha(){return fecha;}
}
