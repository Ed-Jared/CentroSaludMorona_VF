package util;

import java.awt.Component;
import java.awt.Window;
import javax.swing.*;
import javax.swing.text.*;
import Pacientes.AppData;

public final class Util {
  public static final int MAX_MEDICOS_NUEVOS=5;
  private Util(){}

  public static JComboBox<String> especialidades(){
    return new JComboBox<>(AppData.specialties().toArray(new String[0]));
  }

  public static boolean dniValido(String d){return AppData.validDni(d);}

  public static void error(Window w,String m){
    JOptionPane.showMessageDialog(w,m,"Validación",JOptionPane.WARNING_MESSAGE);
  }

  public static void info(Window w,String m){
    JOptionPane.showMessageDialog(w,m,"Centro de Salud Morona",JOptionPane.INFORMATION_MESSAGE);
  }

  /** Limits a DNI input to exactly numeric characters and a maximum of 8 digits. */
  public static void limitarDni(JTextComponent field, Component parent) {
    ((AbstractDocument) field.getDocument()).setDocumentFilter(new DocumentFilter() {
      @Override
      public void insertString(FilterBypass fb, int offset, String text, AttributeSet attrs)
          throws BadLocationException {
        replace(fb, offset, 0, text, attrs);
      }

      @Override
      public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
          throws BadLocationException {
        String current = fb.getDocument().getText(0, fb.getDocument().getLength());
        String result = current.substring(0, offset)
            + (text == null ? "" : text)
            + current.substring(offset + length);
        if (result.length() > 8) {
          JOptionPane.showMessageDialog(parent, "El DNI no puede tener más de 8 caracteres.");
          return;
        }
        if (text != null && !text.matches("\\d*")) {
          return;
        }
        if (!result.isEmpty() && result.charAt(0) == '0') {
          return;
        }
        fb.replace(offset, length, text, attrs);
      }
    });
  }
}
